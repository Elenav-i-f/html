# Tarjetas de red

## Especificaciones

| Nombre/Recursos                                       |  Precio   |              Velocidad (Mbits)              | Cantidad de puertos |              Tipo de puertos               | Tipo de conexión a la placa |         Tecnologías extra         |
| ----------------------------------------------------- | :-------: | :-----------------------------------------: | :-----------------: | :----------------------------------------: | :-------------------------: | :-------------------------------: |
| ASUS PCE-AX1800                                       |   22,99   |                    1800                     |          0          |                     Xd                     |           PCIe x1           |    2 antenas WiFi y Bluetooth     |
| HPE NIC CN1100R StoreFabric Converged Network Adapter |  229,95   |                    25000                    |          2          | Ethernet y fibra (depende del transceptor) |           PCIe x8           | Es convergente, y de segunda mano |
| Broadcom BCM56970 Tomahawk 2                          | 13.905,32 | 100000 por cada puerto, y 6400000 en total. |         64          |                  Ethernet                  |          Ethernet           |           Va muy rápido           |

